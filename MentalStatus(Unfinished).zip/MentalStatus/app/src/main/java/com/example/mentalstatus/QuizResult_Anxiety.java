package com.example.mentalstatus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class QuizResult_Anxiety extends AppCompatActivity {

    private List<AnxietyQuestionList> anxietyQuestionLists = new ArrayList<>();


    TextView evaluationResult, evalDes, score, totalQuestion;
    AppCompatButton backHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_result_anxiety);


        evaluationResult = findViewById(R.id.evalResult);
        evalDes = findViewById(R.id.evalDesc);
        score = findViewById(R.id.score);
        totalQuestion = findViewById(R.id.questionTotal);

        backHome = findViewById(R.id.homeBtn);

        //Getting list from Depression Test Activity
        anxietyQuestionLists = (List<AnxietyQuestionList>) getIntent().getSerializableExtra("anxietyOption");

        totalQuestion.setText("out of " + 21);
        score.setText(getTotalScore() + "");

        backHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(QuizResult_Anxiety.this, MainActivity.class));
            }
        });
    }

    private int getTotalScore(){
        int equivalentScore = 0;

        for(int i = 0; i < anxietyQuestionLists.size(); i++) {

            int getUserAnswerEquivalent = anxietyQuestionLists.get(i).getUserSelectedAnswerEquivalent();
            equivalentScore += getUserAnswerEquivalent;
            if(equivalentScore>=15){
                evaluationResult.setText("Severe Anxiety");
                evalDes.setText("Your results indicate that you may be experiencing symptoms of severe anxiety. Based on your answers, these symptoms seem to be greatly interfering with your relationships and the tasks of everyday life. These result do not mean that you have depression, but we recommend you start a conversation with a mental health professional.");
            }
            else if(equivalentScore<15&&equivalentScore>9){
                evaluationResult.setText("Moderate Anxiety");
                evalDes.setText("Your results indicate that you may be experiencing symptoms of moderate depression. Based on your answers, living with these symptoms could be causing difficulty managing relationships and even the task of everyday life. These result do not mean that you have anxiety, but it may be time to start a conversation with a mental health professional");
            }
            else if(equivalentScore<10&&equivalentScore==5){
                evaluationResult.setText("Mild Anxiety");
                evalDes.setText("Your results indicate that you may be experiencing symptoms of mild anxiety. While your symptoms are not likely having a major impact on your life, it is important to monitor them. These result do not mean that you have depression, but it may be time to start a conversation with a mental health professional");
            }
            else if(equivalentScore==0){
                evaluationResult.setText("Minimal Anxiety");
                evalDes.setText("Your results indicate that you have none, or vey few symptoms of anxiety. If you notice that your symptoms aren't improving, you may want to bring them up with a mental health professional or someone who is supporting you");
            }
        }

        return equivalentScore;

    }
}