package com.example.mentalstatus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Landing_AnxTest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_anx_test);
    }
}