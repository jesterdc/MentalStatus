package com.example.mentalstatus;

import java.io.Serializable;

public class DepressionQuestionList implements Serializable {
    //, question2, question3, question4, question5, question6, question7, question8, question9, question10
    private final String question;
    private final String option1, option2, option3, option4;
    private int userSelectedAnswer;


    //String question2, String question3, String question4, String question5, String question6, String question7, String question8, String question9, String question10,
    //        this.question2 = question2;
    //        this.question3 = question3;
    //        this.question4 = question4;
    //        this.question5 = question5;
    //        this.question6 = question6;
    //        this.question7 = question7;
    //        this.question8 = question8;
    //        this.question9 = question9;
    //        this.question10 = question10;

    public DepressionQuestionList(String question, String option1, String option2, String option3, String option4) {
        this.question = question;
        this.option1 = option1;
        this.option2 = option2;
        this.option3 = option3;
        this.option4 = option4;
        this.userSelectedAnswer = 0;
    }


    public String getQuestion() {
        return question;
    }

    /*public String getQuestion2() {
        return question2;
    }

    public String getQuestion3() {
        return question3;
    }

    public String getQuestion4() {
        return question4;
    }

    public String getQuestion5() {
        return question5;
    }

    public String getQuestion6() {
        return question6;
    }

    public String getQuestion7() {
        return question7;
    }

    public String getQuestion8() {
        return question8;
    }

    public String getQuestion9() {
        return question9;
    }

    public String getQuestion10() {
        return question10;
    }*/

    public String getOption1() {
        String option1 = "Never";
        return option1;
    }

    public String getOption2() {
        String option2 = "Some of the time";
        return option2;
    }

    public String getOption3() {
        String option3 = "Most of the time";
        return option3;
    }

    public String getOption4() {
        String option4 = "Nearly all the time";
        return option4;
    }

    public int getUserSelectedAnswer() {
        return userSelectedAnswer;
    }

    public void setUserSelectedAnswer(int userSelectedAnswer) {
        this.userSelectedAnswer = userSelectedAnswer;
    }
}
