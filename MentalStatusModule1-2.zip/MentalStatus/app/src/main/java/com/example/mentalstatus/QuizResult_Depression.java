package com.example.mentalstatus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class QuizResult_Depression extends AppCompatActivity {

    private List<DepressionQuestionList> depressionQuestionLists = new ArrayList<>();


    TextView evaluationResult, score, totalQuestion;
    AppCompatButton backHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_result_depression);

        evaluationResult = findViewById(R.id.evalResult);
        score = findViewById(R.id.score);
        totalQuestion = findViewById(R.id.questionTotal);

        backHome = findViewById(R.id.homeBtn);

        //Getting list from Depression Test Activity
        depressionQuestionLists = (List<DepressionQuestionList>) getIntent().getSerializableExtra("questions");

        totalQuestion.setText("/"+depressionQuestionLists.size());
        score.setText(getTotalScore() + "");

        backHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(QuizResult_Depression.this, MainActivity.class));
            }
        });
    }

    private int getTotalScore(){

        int correctAnswer = 0;

        for(int i = 0; i < depressionQuestionLists.size(); i++){

            int getUserSelectedOption = depressionQuestionLists.get(i).getUserSelectedAnswer(); //Get user selected option
        }

        return correctAnswer;

    }
}